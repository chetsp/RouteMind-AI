Open your reviewer HTML in a browser, rate independently and download your ratings CSV.
10 cases per reviewer, with 5 shared for agreement checks. No ratings have been completed.
This pack uses OFFLINE retrieval-only results, not generated live-model answers.
Regenerate from a live report to review live policy answers. See evaluations/quality/REVIEW_GUIDE.md for scoring and aggregation.
